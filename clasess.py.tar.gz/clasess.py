# Clase base
class Fabrica:
    def __init__(self, llantas, color, precio):
        self.llantas = llantas
        self.color = color
        self.precio = precio

    def mostrar_info(self):
        return f"Llantas: {self.llantas}, Color: {self.color}, Precio: ${self.precio}"

    def aplicar_descuento(self):
        if self.precio > 100000:
            descuento = 0.10 * self.precio
            self.precio -= descuento
            return f"Descuento aplicado: ${descuento}. Precio con descuento: ${self.precio}"
        else:
            return "No se aplica descuento."

# Clase derivada para Autos
class Auto(Fabrica):
    def __init__(self, llantas, color, precio, tipo_carroceria):
        super().__init__(llantas, color, precio)
        self.tipo_carroceria = tipo_carroceria

    def mostrar_info(self):
        info_base = super().mostrar_info()
        return f"{info_base}, Tipo de Carrocería: {self.tipo_carroceria}"

# Clase derivada para Motos
class Moto(Fabrica):
    def __init__(self, llantas, color, precio, tipo_motor):
        super().__init__(llantas, color, precio)
        self.tipo_motor = tipo_motor

    def mostrar_info(self):
        info_base = super().mostrar_info()
        return f"{info_base}, Tipo de Motor: {self.tipo_motor}"

# Crear objetos de las clases derivadas
auto = Auto(llantas=4, color="Rojo", precio=200000, tipo_carroceria="Sedán")
moto = Moto(llantas=2, color="Azul", precio=5000, tipo_motor="2T")

# Mostrar la información de los vehículos y aplicar el descuento
print("Información del Auto:")
print(auto.mostrar_info())
print(auto.aplicar_descuento())

print("\nInformación de la Moto:")
print(moto.mostrar_info())
print(moto.aplicar_descuento())

