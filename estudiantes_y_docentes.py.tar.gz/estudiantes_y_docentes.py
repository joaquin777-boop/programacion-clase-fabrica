# Clase base Persona
class Persona:
    def __init__(self, matricula, dni, nombre_apellido, direccion):
        self.matricula = matricula
        self.dni = dni
        self.nombre_apellido = nombre_apellido
        self.direccion = direccion

    def mostrar_datos(self):
        print(f"Matricula: {self.matricula}")
        print(f"DNI: {self.dni}")
        print(f"Nombre y Apellido: {self.nombre_apellido}")
        print(f"Dirección: {self.direccion}")

# Clase Estudiante que hereda de Persona
class Estudiante(Persona):
    def __init__(self, matricula, dni, nombre_apellido, direccion, anio_curso):
        super().__init__(matricula, dni, nombre_apellido, direccion)
        self.anio_curso = anio_curso

    def mostrar_datos(self):
        super().mostrar_datos()
        print(f"Año de Curso: {self.anio_curso}")

# Clase Docente que hereda de Persona
class Docente(Persona):
    def __init__(self, matricula, dni, nombre_apellido, direccion, cursos_acargo):
        super().__init__(matricula, dni, nombre_apellido, direccion)
        self.cursos_acargo = cursos_acargo

    def mostrar_datos(self):
        super().mostrar_datos()
        print(f"Cursos a Cargo: {', '.join(self.cursos_acargo)}")

# Crear objetos de Estudiante
estudiante1 = Estudiante(matricula="E001", dni="12345678", nombre_apellido="Juan Pérez", direccion="Av. Siempre Viva 123", anio_curso=3)
estudiante2 = Estudiante(matricula="E002", dni="23456789", nombre_apellido="Ana Gómez", direccion="Calle Falsa 456", anio_curso=2)
estudiante3 = Estudiante(matricula="E003", dni="34567890", nombre_apellido="Luis Fernández", direccion="Boulevard del Río 789", anio_curso=1)

# Crear objetos de Docente
docente1 = Docente(matricula="D001", dni="45678901", nombre_apellido="Laura Martínez", direccion="Avenida Central 101", cursos_acargo=["Matemáticas", "Física"])
docente2 = Docente(matricula="D002", dni="56789012", nombre_apellido="Carlos Rodríguez", direccion="Calle Luna 202", cursos_acargo=["Historia", "Geografía"])
docente3 = Docente(matricula="D003", dni="67890123", nombre_apellido="María López", direccion="Avenida del Sol 303", cursos_acargo=["Biología", "Química"])

# Mostrar datos de estudiantes
print("Datos del Estudiante 1:")
estudiante1.mostrar_datos()
print()  # Línea en blanco para separar salida

print("Datos del Estudiante 2:")
estudiante2.mostrar_datos()
print()  # Línea en blanco para separar salida

print("Datos del Estudiante 3:")
estudiante3.mostrar_datos()
print()  # Línea en blanco para separar salida

# Mostrar datos de docentes
print("Datos del Docente 1:")
docente1.mostrar_datos()
print()  # Línea en blanco para separar salida

print("Datos del Docente 2:")
docente2.mostrar_datos()
print()  # Línea en blanco para separar salida

print("Datos del Docente 3:")
docente3.mostrar_datos()
